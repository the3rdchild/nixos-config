pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import Caelestia
import Caelestia.Config
import qs.utils

Singleton {
    id: root

    property string city
    property string loc
    property var cc
    property list<var> forecast
    property list<var> hourlyForecast

    property bool ipApiRequestPending: false
    property double ipApiBlockedUntil: 0
    property bool citiesLoaded: false
    property string pendingCoords

    readonly property string icon: cc ? Icons.getWeatherIcon(cc.weatherCode) : "cloud_alert"
    readonly property string description: cc?.weatherDesc ?? qsTr("No weather")
    readonly property string temp: formatTemp(cc?.tempC)
    readonly property string feelsLike: formatTemp(cc?.feelsLikeC)
    readonly property int humidity: cc?.humidity ?? 0
    readonly property real windSpeed: cc?.windSpeed ?? 0
    readonly property string sunrise: cc ? Qt.formatDateTime(new Date(cc.sunrise), GlobalConfig.services.useTwelveHourClock ? "h:mm A" : "h:mm") : "--:--"
    readonly property string sunset: cc ? Qt.formatDateTime(new Date(cc.sunset), GlobalConfig.services.useTwelveHourClock ? "h:mm A" : "h:mm") : "--:--"

    readonly property var cachedCities: new Map()

    function formatTemp(temp: var): string {
        return GlobalConfig.services.useFahrenheit ? `${temp !== undefined ? Math.round(toFahrenheit(temp)) : "--"}°F` : `${temp !== undefined ? Math.round(temp) : "--"}°C`;
    }

    function reload(): void {
        const configLocation = GlobalConfig.services.weatherLocation;

        if (configLocation) {
            if (configLocation.indexOf(",") !== -1 && !isNaN(parseFloat(configLocation.split(",")[0]))) {
                loc = configLocation;
                fetchCityFromCoords(configLocation);
            } else {
                fetchCoordsFromCity(configLocation);
            }
        } else if ((!loc || timer.elapsed() > 900) && !ipApiRequestPending && Date.now() >= ipApiBlockedUntil) {
            ipApiRequestPending = true;

            Requests.get("http://ip-api.com/json?fields=status,message,city,lat,lon", (text, metadata) => {
                ipApiRequestPending = false;
                recordIpApiRateLimit(metadata);

                // Protect against stale responses overwriting the manually-set location,
                // in case the config was updated while this request was in-flight.
                if (GlobalConfig.services.weatherLocation)
                    return;

                let response;
                try {
                    response = JSON.parse(text);
                } catch (error) {
                    console.warn(lc, `Unable to parse response from ip-api: ${error}`);
                    return;
                }

                const lat = Number(response.lat);
                const lon = Number(response.lon);

                if (response.status !== "success" || !Number.isFinite(lat) || !Number.isFinite(lon)) {
                    console.warn(lc, `ip-api lookup failed: ${response.message ?? "invalid response"}`);
                    return;
                }

                city = fixCityName(response.city ?? "");
                timer.restart();
                loc = `${lat},${lon}`;
            }, (error, metadata) => {
                ipApiRequestPending = false;

                if (!recordIpApiRateLimit(metadata))
                    console.warn(lc, `ip-api request failed: ${error}`);
            });
        }
    }

    function recordIpApiRateLimit(metadata: var): bool {
        const remainingHeader = metadata?.headers?.["x-rl"];
        const exhausted = remainingHeader !== undefined && Number(remainingHeader) === 0;

        if (metadata?.statusCode !== 429 && !exhausted)
            return false;

        const ttlHeader = metadata?.headers?.["x-ttl"];
        const ttl = Number(ttlHeader);

        const delaySeconds = Number.isFinite(ttl) ? Math.max(1, Math.ceil(ttl) + 1) : 61;

        const delayMs = delaySeconds * 1000;
        ipApiBlockedUntil = Date.now() + delayMs;
        ipApiRetryTimer.interval = delayMs;
        ipApiRetryTimer.restart();

        return true;
    }

    function fixCityName(cityName: string): string {
        if (!cityName)
            return "";
        const mapping = {
            // Polish
            "Poznan": "Poznań",
            "Wroclaw": "Wrocław",
            "Krakow": "Kraków",
            "Gdansk": "Gdańsk",
            "Lodz": "Łódź",
            "Rzeszow": "Rzeszów",
            "Torun": "Toruń",
            "Bialystok": "Białystok",
            "Czestochowa": "Częstochowa",
            "Plock": "Płock",
            "Ruda Slaska": "Ruda Śląska",
            "Dabrowa Gornicza": "Dąbrowa Górnicza",
            "Elblag": "Elbląg",
            "Gorzow Wielkopolski": "Gorzów Wielkopolski",
            "Zielona Gora": "Zielona Góra",
            "Slupsk": "Słupsk",

            // German
            "Munchen": "München",
            "Koln": "Köln",
            "Dusseldorf": "Düsseldorf",
            "Nurnberg": "Nürnberg",

            // French & Spanish & Portuguese
            "Sao Paulo": "São Paulo",
            "Montreal": "Montréal",
            "Quebec": "Québec",
            "Bogota": "Bogotá",
            "Medellin": "Medellín",
            "Cordoba": "Córdoba",

            // Turkish
            "Istanbul": "İstanbul",
            "Izmir": "İzmir",

            // Scandinavian & others
            "Malmo": "Malmö",
            "Goteborg": "Göteborg",
            "Zurich": "Zürich",
            "Geneve": "Genève"
        };
        return mapping[cityName] || cityName;
    }

    function cacheCity(coords: string, cityName: string): void {
        cachedCities.set(coords, cityName);
        citiesSaveTimer.restart();
    }

    function fetchCityFromCoords(coords: string): void {
        if (cachedCities.has(coords)) {
            city = cachedCities.get(coords);
            return;
        }

        // Defer until cache is loaded
        if (!citiesLoaded) {
            pendingCoords = coords;
            return;
        }

        const [lat, lon] = coords.split(",").map(s => s.trim());
        const lang = Qt.locale().name.split("_")[0] || "en";

        const nominatimUrl = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=geocodejson&accept-language=${lang}`;
        const nominatimHeaders = {
            "User-Agent": `caelestia-shell/${CUtils.version} (+https://github.com/caelestia-dots/shell)`
        };

        Requests.get(nominatimUrl, text => {
            let geo;
            try {
                geo = JSON.parse(text).features?.[0]?.properties.geocoding;
            } catch (error) {
                console.warn(lc, `Unable to parse response from nominatim: ${error}`);
                city = qsTr("Unknown City");
                return;
            }

            if (geo) {
                const geoCity = geo.type === "city" ? geo.name : geo.city;
                if (geoCity) {
                    city = fixCityName(geoCity);
                    cacheCity(coords, city);
                    return;
                }
            }

            console.warn(lc, "No locality in nominatim response");
            city = qsTr("Unknown City");
        }, error => {
            console.warn(lc, `Nominatim request failed: ${error}`);
            city = qsTr("Unknown City");
        }, nominatimHeaders);
    }

    function fetchCoordsFromCity(cityName: string): void {
        const lang = Qt.locale().name.split("_")[0] || "en";
        const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=1&language=${lang}&format=json`;

        Requests.get(url, text => {
            const json = JSON.parse(text);
            if (json.results && json.results.length > 0) {
                const result = json.results[0];
                loc = result.latitude + "," + result.longitude;
                city = fixCityName(result.name);
            } else {
                loc = "";
                reload();
            }
        });
    }

    function fetchWeatherData(): void {
        const url = getWeatherUrl();
        if (url === "")
            return;

        Requests.get(url, text => {
            const json = JSON.parse(text);
            if (!json.current || !json.daily)
                return;

            cc = {
                weatherCode: json.current.weather_code,
                weatherDesc: getWeatherCondition(json.current.weather_code),
                tempC: json.current.temperature_2m,
                feelsLikeC: json.current.apparent_temperature,
                humidity: json.current.relative_humidity_2m,
                windSpeed: json.current.wind_speed_10m,
                isDay: json.current.is_day,
                sunrise: json.daily.sunrise[0].replace("T", " "),
                sunset: json.daily.sunset[0].replace("T", " ")
            };

            const forecastList = [];
            for (let i = 0; i < json.daily.time.length; i++)
                forecastList.push({
                    date: json.daily.time[i].replace(/-/g, "/"),
                    maxTempC: json.daily.temperature_2m_max[i],
                    minTempC: json.daily.temperature_2m_min[i],
                    weatherCode: json.daily.weather_code[i],
                    icon: Icons.getWeatherIcon(json.daily.weather_code[i])
                });
            forecast = forecastList;

            const hourlyList = [];
            const now = new Date();
            for (let i = 0; i < json.hourly.time.length; i++) {
                const time = new Date(json.hourly.time[i].replace("T", " "));

                if (time < now)
                    continue;

                hourlyList.push({
                    timestamp: json.hourly.time[i],
                    hour: time.getHours(),
                    tempC: Math.round(json.hourly.temperature_2m[i]),
                    precipChance: json.hourly.precipitation_probability[i],
                    weatherCode: json.hourly.weather_code[i],
                    icon: Icons.getWeatherIcon(json.hourly.weather_code[i])
                });
            }
            hourlyForecast = hourlyList;
        });
    }

    function toFahrenheit(celsius: real): real {
        return celsius * 9 / 5 + 32;
    }

    function getWeatherUrl(): string {
        if (!loc || loc.indexOf(",") === -1)
            return "";

        const [lat, lon] = loc.split(",").map(s => s.trim());
        const baseUrl = "https://api.open-meteo.com/v1/forecast";
        const params = ["latitude=" + lat, "longitude=" + lon, "hourly=weather_code,temperature_2m,precipitation_probability", "daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset", "current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m", "timezone=auto", "forecast_days=7"];

        return baseUrl + "?" + params.join("&");
    }

    function getWeatherCondition(code: string): string {
        const conditions = {
            "0": "Clear",
            "1": "Clear",
            "2": "Partly cloudy",
            "3": "Overcast",
            "45": "Fog",
            "48": "Fog",
            "51": "Drizzle",
            "53": "Drizzle",
            "55": "Drizzle",
            "56": "Freezing drizzle",
            "57": "Freezing drizzle",
            "61": "Light rain",
            "63": "Rain",
            "65": "Heavy rain",
            "66": "Light rain",
            "67": "Heavy rain",
            "71": "Light snow",
            "73": "Snow",
            "75": "Heavy snow",
            "77": "Snow",
            "80": "Light rain",
            "81": "Rain",
            "82": "Heavy rain",
            "85": "Light snow showers",
            "86": "Heavy snow showers",
            "95": "Thunderstorm",
            "96": "Thunderstorm with hail",
            "99": "Thunderstorm with hail"
        };
        return conditions[code] || "Unknown";
    }

    onLocChanged: fetchWeatherData()
    onCitiesLoadedChanged: {
        if (!citiesLoaded || !pendingCoords)
            return;

        const coords = pendingCoords;
        pendingCoords = "";
        fetchCityFromCoords(coords);
    }

    Connections {
        function onWeatherLocationChanged(): void {
            root.reload();
        }

        target: GlobalConfig.services
    }

    Timer {
        interval: 3600000 // 1 hour
        running: true
        repeat: true
        onTriggered: fetchWeatherData()
    }

    Timer {
        id: ipApiRetryTimer

        repeat: false

        onTriggered: {
            const remaining = root.ipApiBlockedUntil - Date.now();

            if (remaining > 0) {
                interval = Math.ceil(remaining);
                restart();
            } else {
                root.reload();
            }
        }
    }

    Timer {
        id: citiesSaveTimer

        interval: 1000
        onTriggered: {
            if (!root.citiesLoaded)
                return;

            const data = {};
            root.cachedCities.forEach((cityName, coords) => data[coords] = cityName);
            citiesStorage.setText(JSON.stringify(data));
        }
    }

    ElapsedTimer {
        id: timer
    }

    FileView {
        id: citiesStorage

        printErrors: false
        path: `${Paths.cache}/cities.json`
        onLoaded: {
            try {
                const data = JSON.parse(text());
                for (const [coords, cityName] of Object.entries(data))
                    if (!root.cachedCities.has(coords))
                        root.cachedCities.set(coords, cityName);
            } catch (error) {
                console.warn(lc, `Unable to parse cached cities: ${error}`);
            }

            root.citiesLoaded = true;
        }
        onLoadFailed: err => {
            root.citiesLoaded = true;
            if (err === FileViewError.FileNotFound)
                Qt.callLater(() => setText("{}"));
            else
                console.warn(lc, `Unable to load cached cities: ${err}`);
        }
    }

    LoggingCategory {
        id: lc

        name: "caelestia.qml.services.weather"
        defaultLogLevel: LoggingCategory.Info
    }
}
