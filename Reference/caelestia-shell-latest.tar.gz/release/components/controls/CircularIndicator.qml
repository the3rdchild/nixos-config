import QtQuick
import QtQuick.Templates
import Caelestia.Config
import Caelestia.Internal
import qs.components
import qs.services

BusyIndicator {
    id: root

    enum AnimType {
        Advance = 0,
        Retreat
    }

    enum AnimState {
        Stopped,
        Running,
        Completing
    }

    property real implicitSize: Tokens.font.body.medium.pointSize * 3
    property real strokeWidth: Tokens.padding.extraSmall
    property color fgColour: Colours.palette.m3primary
    property color bgColour: Colours.palette.m3secondaryContainer

    property alias type: manager.indeterminateAnimationType
    readonly property alias progress: manager.progress

    property real internalStrokeWidth: strokeWidth
    property int animState

    padding: 0
    implicitWidth: implicitSize
    implicitHeight: implicitSize

    Component.onCompleted: {
        if (running) {
            running = false;
            running = true;
        }
    }

    onRunningChanged: {
        if (running) {
            manager.completeEndProgress = 0;
            animState = CircularIndicator.Running;
        } else {
            if (animState == CircularIndicator.Running)
                animState = CircularIndicator.Completing;
        }
    }

    states: State {
        name: "stopped"
        when: !root.running

        PropertyChanges {
            root.opacity: 0
            root.internalStrokeWidth: root.strokeWidth / 3
        }
    }

    transitions: Transition {
        Anim {
            type: Anim.DefaultEffects
            properties: "opacity,internalStrokeWidth"
            duration: manager.completeEndDuration * Tokens.anim.durations.scale
        }
    }

    contentItem: CircularProgress {
        anchors.fill: parent
        strokeWidth: root.internalStrokeWidth
        fgColour: root.fgColour
        bgColour: root.bgColour
        padding: root.padding
        rotation: manager.rotation
        startAngle: manager.startFraction * 360
        value: manager.endFraction - manager.startFraction
        hasEndIndicator: false
    }

    CircularIndicatorManager {
        id: manager
    }

    NumberAnimation {
        running: root.animState !== CircularIndicator.Stopped
        loops: Animation.Infinite
        target: manager
        property: "progress"
        from: 0
        to: 1
        duration: manager.duration * Tokens.anim.durations.scale
    }

    NumberAnimation {
        running: root.animState === CircularIndicator.Completing
        target: manager
        property: "completeEndProgress"
        from: 0
        to: 1
        duration: manager.completeEndDuration * Tokens.anim.durations.scale
        onFinished: {
            if (root.animState === CircularIndicator.Completing)
                root.animState = CircularIndicator.Stopped;
        }
    }
}
